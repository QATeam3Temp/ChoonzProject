$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/cuke/UpdateFunction.feature");
formatter.feature({
  "line": 1,
  "name": "Choonz website",
  "description": "",
  "id": "choonz-website",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "",
  "description": "",
  "id": "choonz-website;",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for \u003centity\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a \u003centity2\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "choonz-website;;",
  "rows": [
    {
      "cells": [
        "entity",
        "entity2"
      ],
      "line": 12,
      "id": "choonz-website;;;1"
    },
    {
      "cells": [
        "tracks",
        "track"
      ],
      "line": 13,
      "id": "choonz-website;;;2"
    },
    {
      "cells": [
        "genres",
        "genre"
      ],
      "line": 14,
      "id": "choonz-website;;;3"
    },
    {
      "cells": [
        "artists",
        "artist"
      ],
      "line": 15,
      "id": "choonz-website;;;4"
    },
    {
      "cells": [
        "album",
        "album"
      ],
      "line": 16,
      "id": "choonz-website;;;5"
    },
    {
      "cells": [
        "playlist",
        "playlist"
      ],
      "line": 17,
      "id": "choonz-website;;;6"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 13,
  "name": "",
  "description": "",
  "id": "choonz-website;;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for tracks",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a track",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 14,
  "name": "",
  "description": "",
  "id": "choonz-website;;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for genres",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a genre",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 15,
  "name": "",
  "description": "",
  "id": "choonz-website;;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for artists",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a artist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 16,
  "name": "",
  "description": "",
  "id": "choonz-website;;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for album",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a album",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 17,
  "name": "",
  "description": "",
  "id": "choonz-website;;;6",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the update page for playlist",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to update a playlist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});