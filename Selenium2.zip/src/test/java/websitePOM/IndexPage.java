package websitePOM;

public class IndexPage {

}
