package websitePOM;

public class LoginPage {

}
