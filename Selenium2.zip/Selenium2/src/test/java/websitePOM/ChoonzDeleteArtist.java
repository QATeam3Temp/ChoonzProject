package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzDeleteArtist {

	public static final String URL = "http://localhost:8082/delete?x=artists";
	
	@FindBy(id = "swordOfDamocles")
    private WebElement artistListing;
	
	@FindBy(xpath = "//option[contains(text(),'test2')]")
	private WebElement artist1;
	
	@FindBy(xpath = "//button[contains(text(),'delet this')]")
	private WebElement deleteArtist;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement navigateHome;

	public void deleteArtist() {
		artistListing.click();
		artist1.click();
		deleteArtist.click();
	}
	
	public void home() {
		navigateHome.click();
	}
	
}
