package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzDeleteTrack {
	
	public static final String URL = "http://localhost:8082/delete?x=tracks";

	@FindBy(id = "swordOfDamocles")
    private WebElement trackListing;
	
	@FindBy(xpath = "//option[contains(text(),'test2')]")
	private WebElement track1;
	
	@FindBy(xpath = "//button[contains(text(),'delet this')]")
	private WebElement deleteTrack;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement navigateHome;
	
	public void deleteTrack() {
		trackListing.click();
		track1.click();
		deleteTrack.click();
	}
	
	public void home() {
		navigateHome.click();
	}
	
}
