package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzDeletePlaylist {

	public static final String URL = "http://localhost:8082/delete?x=playlists";

	@FindBy(id = "swordOfDamocles")
	private WebElement playlistListing;

	@FindBy(xpath = "//option[contains(text(),'test')]")
	private WebElement playlist1;

	@FindBy(xpath = "//button[contains(text(),'delet this')]")
	private WebElement deletePlaylist;

	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement navigateHome;

	public void deleteAlbum() {
		playlistListing.click();
		playlist1.click();
		deletePlaylist.click();
	}

	public void home() {
		navigateHome.click();
	}

}
