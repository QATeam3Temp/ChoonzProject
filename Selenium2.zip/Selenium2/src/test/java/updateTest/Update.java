package updateTest;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Update {
	
	
	
	@Given("^I have accessed the website$")
	public void i_have_accessed_the_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Registered and logged in$")
	public void registered_and_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@And("^I navigate to the update page for tracks$")
	public void i_navigate_to_the_update_page_for_tracks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will select the fields to update a track$")
	public void i_will_select_the_fields_to_update_a_track() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@And("^I navigate to the update page for genres$")
	public void i_navigate_to_the_update_page_for_genres() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will select the fields to update a genre$")
	public void i_will_select_the_fields_to_update_a_genre() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@And("^I navigate to the update page for artists$")
	public void i_navigate_to_the_update_page_for_artists() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will select the fields to update a artist$")
	public void i_will_select_the_fields_to_update_a_artist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@And("^I navigate to the update page for album$")
	public void i_navigate_to_the_update_page_for_album() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will select the fields to update a album$")
	public void i_will_select_the_fields_to_update_a_album() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@And("^I navigate to the update page for playlist$")
	public void i_navigate_to_the_update_page_for_playlist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I will select the fields to update a playlist$")
	public void i_will_select_the_fields_to_update_a_playlist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
