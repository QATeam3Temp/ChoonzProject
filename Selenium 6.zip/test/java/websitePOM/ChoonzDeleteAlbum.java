package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzDeleteAlbum {

	public static final String URL = "http://localhost:8082/delete?x=albums";

	@FindBy(id = "swordOfDamocles")
	private WebElement albumListing;

	@FindBy(xpath = "//option[contains(text(),'testalbum')]")
	private WebElement album1;

	@FindBy(xpath = "//button[contains(text(),'delet this')]")
	private WebElement deleteAlbum;

	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement navigateHome;

	public void deleteAlbum() {
		albumListing.click();
		album1.click();
		deleteAlbum.click();
	}

	public void home() {
		navigateHome.click();
	}

	public void showDeleted() {
		albumListing.click();
	}

}
