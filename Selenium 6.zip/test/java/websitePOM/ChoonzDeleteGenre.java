package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzDeleteGenre {

	public static final String URL = "http://localhost:8082/delete?x=genres";
	
	@FindBy(id = "swordOfDamocles")
    private WebElement genreListing;
	
	@FindBy(xpath = "//option[contains(text(),'testgenre')]")
	private WebElement genre1;
	
	@FindBy(xpath = "//button[contains(text(),'delet this')]")
	private WebElement deleteGenre;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement navigateHome;

	public void deleteGenre() {
		genreListing.click();
		genre1.click();
		deleteGenre.click();
	}
	
	public void home() {
		navigateHome.click();
	}

	public void showDeleted() {
		genreListing.click();
	}
	
}
