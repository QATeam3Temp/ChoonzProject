package deleteTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import websitePOM.ChoonzDeleteAlbum;
import websitePOM.ChoonzDeleteArtist;
import websitePOM.ChoonzDeleteGenre;
import websitePOM.ChoonzDeletePlaylist;
import websitePOM.ChoonzDeleteTrack;
import websitePOM.ChoonzIndexPage;
import websitePOM.ChoonzLoginPage;
import websitePOM.ChoonzRegisterPage;

public class Delete {

	private static WebDriver driver;
	private static boolean ran = false;

	static String username = "test" + Math.random();
	static String password = "test" + Math.random();

	@Before
	public static void init() {
		if (ran) {

		} else {
			ran = true;
			System.setProperty("webdriver.chrome.driver",
					"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
			ChromeOptions cOptions = new ChromeOptions();
			cOptions.setHeadless(true);
			cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
			cOptions.setCapability("network.cookie.cookieBehavior", 2);
			cOptions.setCapability("profiles.block_third_party_cookies", true);
			driver = new ChromeDriver(cOptions);
			driver.manage().window().setSize(new Dimension(1366, 768));

			driver.get(ChoonzIndexPage.URL);
			username = "test" + Math.random();
			password = "test" + Math.random();

			ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
			ChoonzRegisterPage register = PageFactory.initElements(driver, ChoonzRegisterPage.class);
			new WebDriverWait(driver, 5)
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
			index.register();
			assertEquals("Sign Up", driver.getTitle());
			register.register(username, password, password);
		}
	}

	@After
	public void cleanUp() {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.logout();
		driver.manage().deleteAllCookies();
//		driver.close();
	}

	@Given("^I have accessed the website$")
	public void I_have_accessed_the_website() throws InterruptedException {
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^logged in$")
	public void logged_in() throws InterruptedException {
		new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='logarea']")));
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		ChoonzLoginPage login = PageFactory.initElements(driver, ChoonzLoginPage.class);
		index.login();
		assertEquals("Login", driver.getTitle());
		login.register(username, password);
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());
	}

	@And("^I navigate to the delete page for tracks$")
	public void i_navigate_to_the_delete_page_for_tracks() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.deleteTrackNavigation();
	}

	@Then("^I will select the record to delete a track$")
	public void i_will_select_the_record_to_delete_a_track() throws InterruptedException {
		ChoonzDeleteTrack deleteTrack = PageFactory.initElements(driver, ChoonzDeleteTrack.class);
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		deleteTrack.deleteTrack();
		deleteTrack.home();
		index.deleteTrackNavigation();
		deleteTrack.showDeleted();
		deleteTrack.home();
		assertEquals("Choonz Music", driver.getTitle());
	}

	@And("^I navigate to the delete page for genres$")
	public void i_navigate_to_the_delete_page_for_genres() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.deleteGenreNavigation();
	}

	@Then("^I will select the record to delete a genre$")
	public void i_will_select_the_record_to_delete_a_genre() throws InterruptedException {
		ChoonzDeleteGenre deleteGenre = PageFactory.initElements(driver, ChoonzDeleteGenre.class);
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		deleteGenre.deleteGenre();
		deleteGenre.home();
		index.deleteGenreNavigation();
		deleteGenre.showDeleted();
		deleteGenre.home();
		assertEquals("Choonz Music", driver.getTitle());
	}

	@And("^I navigate to the delete page for artists$")
	public void i_navigate_to_the_delete_page_for_artists() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.deleteArtistNavigation();
	}

	@Then("^I will select the record to delete a artist$")
	public void i_will_select_the_record_to_delete_a_artist() throws InterruptedException {
		ChoonzDeleteArtist deleteArtist = PageFactory.initElements(driver, ChoonzDeleteArtist.class);
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		deleteArtist.deleteArtist();
		deleteArtist.home();
		index.deleteArtistNavigation();
		deleteArtist.showDeleted();
		deleteArtist.home();
		assertEquals("Choonz Music", driver.getTitle());
	}

	@And("^I navigate to the delete page for album$")
	public void i_navigate_to_the_delete_page_for_album() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.deleteAlbumNavigation();
	}

	@Then("^I will select the record to delete a album$")
	public void i_will_select_the_record_to_delete_a_album() throws InterruptedException {
		ChoonzDeleteAlbum deleteAlbum = PageFactory.initElements(driver, ChoonzDeleteAlbum.class);
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		deleteAlbum.deleteAlbum();
		deleteAlbum.home();
		index.deleteAlbumNavigation();
		deleteAlbum.showDeleted();
		deleteAlbum.home();
		assertEquals("Choonz Music", driver.getTitle());
	}

	@And("^I navigate to the delete page for playlist$")
	public void i_navigate_to_the_delete_page_for_playlist() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.deletePlaylistNavigation();
	}

	@Then("^I will select the record to delete a playlist$")
	public void i_will_select_the_record_to_delete_a_playlist() throws InterruptedException {
		ChoonzDeletePlaylist deletePlaylist = PageFactory.initElements(driver, ChoonzDeletePlaylist.class);
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		deletePlaylist.deleteAlbum();
		deletePlaylist.home();
		index.deletePlaylistNavigation();
		deletePlaylist.showDeleted();
		deletePlaylist.home();
		assertEquals("Choonz Music", driver.getTitle());
	}

}
