package readLoggedinTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import websitePOM.ChoonzAlbumDetails;
import websitePOM.ChoonzArtistDetails;
import websitePOM.ChoonzGenreDetails;
import websitePOM.ChoonzIndexPage;
import websitePOM.ChoonzLoginPage;
import websitePOM.ChoonzPlaylistDetails;
import websitePOM.ChoonzReadAlbum;
import websitePOM.ChoonzReadArtist;
import websitePOM.ChoonzReadGenre;
import websitePOM.ChoonzReadPlaylist;
import websitePOM.ChoonzReadTracks;
import websitePOM.ChoonzRegisterPage;
import websitePOM.ChoonzTrackDetails;

public class ReadLoggedin {
	
	private static WebDriver driver;
	private static boolean ran = false;
	
	static String username = "test" + Math.random();
	static String password = "test" + Math.random();

	@Before
	public static void init() {
		if (ran) {

		} else {
			ran = true;
			System.setProperty("webdriver.chrome.driver",
					"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
			ChromeOptions cOptions = new ChromeOptions();
			cOptions.setHeadless(true);
			cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
			cOptions.setCapability("network.cookie.cookieBehavior", 2);
			cOptions.setCapability("profiles.block_third_party_cookies", true);
			driver = new ChromeDriver(cOptions);
			driver.manage().window().setSize(new Dimension(1366, 768));
			driver.get(ChoonzIndexPage.URL);
			
			username = "test" + Math.random();
			password = "test" + Math.random();

			ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
			ChoonzRegisterPage register = PageFactory.initElements(driver, ChoonzRegisterPage.class);
			new WebDriverWait(driver, 5)
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
			index.register();
			assertEquals("Sign Up", driver.getTitle());
			register.register(username, password, password);
		}
	}

	@After
	public void cleanUp() {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.logout();
		driver.manage().deleteAllCookies();
//		driver.close();
	}
	
	@Given("^I have logged on$")
	public void i_have_logged_on() throws InterruptedException {
		new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='logarea']")));
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		ChoonzLoginPage login = PageFactory.initElements(driver, ChoonzLoginPage.class);
		index.login();
		assertEquals("Login", driver.getTitle());
		login.register(username, password);
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^I navigate to the read page for tracks$")
	public void i_navigate_to_the_read_page_for_tracks() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readTracks();
	}

	@And("^I will display the record\\(s\\) for tracks on the page$")
	public void i_will_display_the_record_s_for_tracks_on_the_page() throws InterruptedException {
		ChoonzReadTracks readTracks = PageFactory.initElements(driver, ChoonzReadTracks.class);
		readTracks.readTracks();
		assertEquals("testtrack", driver.getTitle());
	}

	@Then("^I will view the details for tracks$")
	public void i_will_view_the_details_for_tracks() throws InterruptedException {
		ChoonzTrackDetails trackDetails = PageFactory.initElements(driver, ChoonzTrackDetails.class);
		trackDetails.selectArtist();
		driver.navigate().back();
		trackDetails.selectAlbum();
		driver.navigate().back();
		assertEquals("testtrack", driver.getTitle());
		trackDetails.selectGenre();
		driver.navigate().back();
		trackDetails.selectPlaylist();
		driver.navigate().back();
		trackDetails.home();
	}

	@When("^I navigate to the read page for genres$")
	public void i_navigate_to_the_read_page_for_genres() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readGenres();
	}

	@And("^I will display the record\\(s\\) for genres on the page$")
	public void i_will_display_the_record_s_for_genres_on_the_page() throws InterruptedException {
		ChoonzReadGenre readGenre = PageFactory.initElements(driver, ChoonzReadGenre.class);
		readGenre.readGenre();
		driver.getCurrentUrl();
		assertEquals("Choonz | testgenre", driver.getTitle());
	}

	@Then("^I will view the details for genres$")
	public void i_will_view_the_details_for_genres() throws InterruptedException {
		ChoonzGenreDetails genreDetails = PageFactory.initElements(driver, ChoonzGenreDetails.class);
		genreDetails.viewAlbum();
		driver.navigate().back();
		genreDetails.home();
	}

	@When("^I navigate to the read page for artists$")
	public void i_navigate_to_the_read_page_for_artists() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readArtists();
	}

	@And("^I will display the record\\(s\\) for artists on the page$")
	public void i_will_display_the_record_s_for_artists_on_the_page() throws InterruptedException {
		ChoonzReadArtist readArtist = PageFactory.initElements(driver, ChoonzReadArtist.class);
		readArtist.readArtist();
		driver.getCurrentUrl();
		assertEquals("Choonz Tracks | testartist", driver.getTitle());
	}

	@Then("^I will view the details for artists$")
	public void i_will_view_the_details_for_artists() throws InterruptedException {
		ChoonzArtistDetails artistDetails = PageFactory.initElements(driver, ChoonzArtistDetails.class);
		artistDetails.viewAlbum();
		driver.navigate().back();
		artistDetails.home();
	}

	@When("^I navigate to the read page for album$")
	public void i_navigate_to_the_read_page_for_album() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readAlbums();
	}

	@And("^I will display the record\\(s\\) for albums on the page$")
	public void i_will_display_the_record_s_for_albums_on_the_page() throws InterruptedException {
		ChoonzReadAlbum readAlbum = PageFactory.initElements(driver, ChoonzReadAlbum.class);
		readAlbum.readAlbum();
		driver.getCurrentUrl();
		assertEquals("testalbum", driver.getTitle());
	}

	@Then("^I will view the details for albums$")
	public void i_will_view_the_details_for_albums() throws InterruptedException {
		ChoonzAlbumDetails albumDetails = PageFactory.initElements(driver, ChoonzAlbumDetails.class);
		albumDetails.viewArtist();
		driver.navigate().back();
		albumDetails.viewGenre();
		driver.navigate().back();
		albumDetails.viewTrack();
		driver.navigate().back();
		albumDetails.home();
		}

	@When("^I navigate to the read page for playlist$")
	public void i_navigate_to_the_read_page_for_playlist() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readPlaylists();
	}

	@And("^I will display the record\\(s\\) for playlists on the page$")
	public void i_will_display_the_record_s_for_playlists_on_the_page() throws InterruptedException {
		ChoonzReadPlaylist readPlaylist = PageFactory.initElements(driver, ChoonzReadPlaylist.class);
		readPlaylist.readPlaylist();
		driver.getCurrentUrl();
		assertEquals("testplaylist", driver.getTitle());
		}

	@Then("^I will view the details for playlists$")
	public void i_will_view_the_details_for_playlists() throws InterruptedException {
		ChoonzPlaylistDetails playlistDetails = PageFactory.initElements(driver, ChoonzPlaylistDetails.class);
		playlistDetails.viewTrack();
		driver.navigate().back();
		playlistDetails.home();}
}

