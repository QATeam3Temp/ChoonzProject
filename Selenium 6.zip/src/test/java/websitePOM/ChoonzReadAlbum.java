package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzReadAlbum {
		
		public static final String URL = "http://localhost:8082/search?x=testalbum";

	 @FindBy(xpath = "//h2[contains(text(),'Playlist: testalbum')]")
	 private WebElement readAlbum;

	public void readAlbum() {
		 readAlbum.click();
	}
}
