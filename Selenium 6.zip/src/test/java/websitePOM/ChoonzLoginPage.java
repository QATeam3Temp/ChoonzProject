package websitePOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChoonzLoginPage {

	public final static String URL = "http://localhost:8082/signup.html";
	
	private WebDriver driver;
	
    public ChoonzLoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(id = "username")
    private WebElement loginUsername;
    
    @FindBy(id = "password")
    private WebElement loginPassword;
    
    @FindBy(id = "submit")
    private WebElement loginBtn;
    
    public void register(String username, String password) {
        loginUsername.sendKeys(username);
        loginPassword.sendKeys(password);
        loginBtn.click();
    }
	
}
