package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzPlaylistDetails {

	public static final String URL = "http://localhost:8082/playlist?id=1";
	
	@FindBy(xpath = "//a[contains(text(),'testtrack')]")
	private WebElement viewTrack;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement home;
	
	public void viewTrack() {
		viewTrack.click();
	}
	
	public void home() {
		home.click();
	}
	
}
