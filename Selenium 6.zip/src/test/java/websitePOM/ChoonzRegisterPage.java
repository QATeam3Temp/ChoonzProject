package websitePOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChoonzRegisterPage {

	public final static String URL = "http://localhost:8082/signup.html";
	
	private WebDriver driver;
	
    public ChoonzRegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(id = "username")
    private WebElement registerUsername;
    
    @FindBy(id = "password")
    private WebElement registerPassword;
    
    @FindBy(id = "confpassword")
    private WebElement registerConfirmPassword;
    
    @FindBy(id = "submit")
    private WebElement registerBtn;
    
    public void register(String username, String password, String confirmPassword) {
        registerUsername.sendKeys(username);
        registerPassword.sendKeys(password);
        registerConfirmPassword.sendKeys(confirmPassword);
        registerBtn.click();
    }
	
}
