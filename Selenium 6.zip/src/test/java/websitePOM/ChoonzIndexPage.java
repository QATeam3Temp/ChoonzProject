package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzIndexPage {

	public static final String URL = "http://localhost:8082/";

	@FindBy(xpath = "//a[contains(text(),'Log in')]")
	private WebElement loginBtn;

	@FindBy(xpath = "//a[contains(text(),'Sign Up')]")
	private WebElement signupBtn;

	@FindBy(xpath = "//a[contains(text(),'Logout')]")
	private WebElement logoutBtn;

	@FindBy(xpath = "//body/div[1]/div[1]/div[4]/button[2]")
	private WebElement trackDropdown;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[4]/div[1]/a[3]")
	private WebElement trackDelete;

	@FindBy(xpath = "//body/div[1]/div[1]/div[3]/button[2]")
	private WebElement genreDropdown;

	@FindBy(xpath = "//body/div[1]/div[1]/div[3]/div[1]/a[3]")
	private WebElement genreDelete;

	@FindBy(xpath = "//body/div[1]/div[1]/div[2]/button[2]")
	private WebElement artistDropdown;

	@FindBy(xpath = "//body/div[1]/div[1]/div[2]/div[1]/a[3]")
	private WebElement artistDelete;

	@FindBy(xpath = "//body/div[1]/div[1]/div[1]/button[2]")
	private WebElement albumDropdown;

	@FindBy(xpath = "//body/div[1]/div[1]/div[1]/div[1]/a[3]")
	private WebElement albumDelete;

	@FindBy(xpath = "//body/div[1]/div[1]/div[5]/button[2]")
	private WebElement playlistDropdown;

	@FindBy(xpath = "//body/div[1]/div[1]/div[5]/div[1]/a[3]")
	private WebElement playlistDelete;

	@FindBy(xpath = "//body/nav[1]/form[1]/input[1]")
	private WebElement searchbar;

	@FindBy(xpath = "//button[@id='searchbar']")
	private WebElement searchSubmit;

	@FindBy(xpath = "//a[contains(text(),'Featured Tracks')]")
	private WebElement readTracks;
	
	@FindBy(xpath = "//a[contains(text(),'Artists')]")
	private WebElement readArtists;
	
	@FindBy(xpath = "//a[contains(text(),'Top Playlists')]")
	private WebElement readPlaylist;
	
	@FindBy(xpath = "//body/div[1]/div[1]/div[5]/div[1]/a[1]")
	private WebElement createPlaylist;
	
	@FindBy(xpath = "//body/div[@id='content']/div[@id='content']/a[1]/div[2]")
	private WebElement playlistHomepage;

	public void register() {
		signupBtn.click();
	}

	public void login() {
		loginBtn.click();
	}

	public void logout() {
		logoutBtn.click();
	}

	public void deleteTrackNavigation() {
		trackDropdown.click();
		trackDelete.click();
	}

	public void deleteGenreNavigation() {
		genreDropdown.click();
		genreDelete.click();
	}

	public void deleteArtistNavigation() {
		artistDropdown.click();
		artistDelete.click();
	}

	public void deleteAlbumNavigation() {
		albumDropdown.click();
		albumDelete.click();
	}

	public void deletePlaylistNavigation() {
		playlistDropdown.click();
		playlistDelete.click();
	}

	public void search(String search) {
		searchbar.sendKeys(search);
		searchSubmit.click();
	}

	public void readTracks() {
		readTracks.click();
	}

	public void readGenres() {
		searchbar.clear();
		searchbar.sendKeys("testgenre");
		searchSubmit.click();
	}
	
	public void readArtists() {
		readArtists.click();
	}
	
	public void readAlbums() {
		searchbar.clear();
		searchbar.sendKeys("testalbum");
		searchSubmit.click();
	}
	
	public void searchTrack() {
		searchbar.sendKeys("testtrack");
		searchSubmit.click();
	}
	
	public void searchPlaylist() {
		searchbar.clear();
		searchbar.sendKeys("testplaylist");
		searchSubmit.click();
	}
	
	public void searchArtist() {
		searchbar.clear();
		searchbar.sendKeys("testartist");
		searchSubmit.click();
	}

	public void readPlaylists() {
		readPlaylist.click();
	}
	
	public void createPlaylist() {
		playlistDropdown.click();
		createPlaylist.click();
	}

	public void playlistHome() {
		playlistHomepage.click();
	}
	
}
