package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzReadGenre {
	
	public static final String URL = "http://localhost:8082/search?x=testgenre";

	 @FindBy(xpath = "//h2[contains(text(),'Genre: testgenre')]")
	 private WebElement readGenre;
	 
	 public void readGenre() {
		 readGenre.click();
	 }
	
}
