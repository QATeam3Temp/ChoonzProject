package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzReadArtist {
	
	public static final String URL = "http://localhost:8082/artists";
	
	@FindBy(xpath = "//a[contains(text(),'testartist')]")
	private WebElement readArtist;
	
	public void readArtist() {
		readArtist.click();
	}

}
