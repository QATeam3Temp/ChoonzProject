$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/cuke/CreateFunction.feature");
formatter.feature({
  "line": 1,
  "name": "Choonz website",
  "description": "",
  "id": "choonz-website",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "",
  "description": "",
  "id": "choonz-website;",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for \u003centity\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a \u003centity2\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "choonz-website;;",
  "rows": [
    {
      "cells": [
        "entity",
        "entity2"
      ],
      "line": 12,
      "id": "choonz-website;;;1"
    },
    {
      "cells": [
        "tracks",
        "track"
      ],
      "line": 13,
      "id": "choonz-website;;;2"
    },
    {
      "cells": [
        "genres",
        "genre"
      ],
      "line": 14,
      "id": "choonz-website;;;3"
    },
    {
      "cells": [
        "artists",
        "artist"
      ],
      "line": 15,
      "id": "choonz-website;;;4"
    },
    {
      "cells": [
        "album",
        "album"
      ],
      "line": 16,
      "id": "choonz-website;;;5"
    },
    {
      "cells": [
        "playlist",
        "playlist"
      ],
      "line": 17,
      "id": "choonz-website;;;6"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 5069136200,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Create.i_have_accessed_the_website()"
});
formatter.result({
  "duration": 335163900,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "",
  "description": "",
  "id": "choonz-website;;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for tracks",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a track",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Create.registered_and_logged_in()"
});
formatter.result({
  "duration": 489231100,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_navigate_to_the_create_page_for_tracks()"
});
formatter.result({
  "duration": 267479700,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_will_select_the_fields_to_create_a_track()"
});
formatter.result({
  "duration": 484124000,
  "status": "passed"
});
formatter.after({
  "duration": 71971600,
  "status": "passed"
});
formatter.before({
  "duration": 27500,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Create.i_have_accessed_the_website()"
});
formatter.result({
  "duration": 5529200,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "",
  "description": "",
  "id": "choonz-website;;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for genres",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a genre",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Create.registered_and_logged_in()"
});
formatter.result({
  "duration": 451974100,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_navigate_to_the_create_page_for_genres()"
});
formatter.result({
  "duration": 159462300,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_will_select_the_fields_to_create_a_genre()"
});
formatter.result({
  "duration": 387511600,
  "status": "passed"
});
formatter.after({
  "duration": 65581200,
  "status": "passed"
});
formatter.before({
  "duration": 33200,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Create.i_have_accessed_the_website()"
});
formatter.result({
  "duration": 5057900,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "",
  "description": "",
  "id": "choonz-website;;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for artists",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a artist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Create.registered_and_logged_in()"
});
formatter.result({
  "duration": 933177700,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_navigate_to_the_create_page_for_artists()"
});
formatter.result({
  "duration": 167563000,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_will_select_the_fields_to_create_a_artist()"
});
formatter.result({
  "duration": 300573900,
  "status": "passed"
});
formatter.after({
  "duration": 84669200,
  "status": "passed"
});
formatter.before({
  "duration": 45600,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Create.i_have_accessed_the_website()"
});
formatter.result({
  "duration": 6810000,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "",
  "description": "",
  "id": "choonz-website;;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for album",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a album",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Create.registered_and_logged_in()"
});
formatter.result({
  "duration": 915820000,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_navigate_to_the_create_page_for_album()"
});
formatter.result({
  "duration": 161343400,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_will_select_the_fields_to_create_a_album()"
});
formatter.result({
  "duration": 809924400,
  "status": "passed"
});
formatter.after({
  "duration": 80717400,
  "status": "passed"
});
formatter.before({
  "duration": 29800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Create.i_have_accessed_the_website()"
});
formatter.result({
  "duration": 5915400,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "",
  "description": "",
  "id": "choonz-website;;;6",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the create page for playlist",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the fields to create a playlist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Create.registered_and_logged_in()"
});
formatter.result({
  "duration": 960046200,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_navigate_to_the_create_page_for_playlist()"
});
formatter.result({
  "duration": 169773800,
  "status": "passed"
});
formatter.match({
  "location": "Create.i_will_select_the_fields_to_create_a_playlist()"
});
formatter.result({
  "duration": 606729800,
  "status": "passed"
});
formatter.after({
  "duration": 69200500,
  "status": "passed"
});
});