package updateTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Update {

	private static WebDriver driver;
	private static String URL = "http://localhost:8082";
	private static boolean ran = false;

	static String username = "test" + Math.random();
	static String password = "test" + Math.random();

	@Before
	public static void init() {
		if (ran) {

		} else {
			ran = true;
			System.setProperty("webdriver.chrome.driver",
					"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
			ChromeOptions cOptions = new ChromeOptions();
			cOptions.setHeadless(true);
			cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
			cOptions.setCapability("network.cookie.cookieBehavior", 2);
			cOptions.setCapability("profiles.block_third_party_cookies", true);
			driver = new ChromeDriver(cOptions);
			driver.manage().window().setSize(new Dimension(1366, 768));
			username = "test" + Math.random();
			password = "test" + Math.random();
			driver.get(URL);
			new WebDriverWait(driver, 5)
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
			WebElement navBarSignUp = driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]"));
			navBarSignUp.click();
			assertEquals("Sign Up", driver.getTitle());
			WebElement enterRegisteringUsername = driver.findElement(By.xpath("//input[@id='username']"));
			WebElement enterRegisteringPassword = driver.findElement(By.xpath("//input[@id='password']"));
			WebElement enterRegisteringConfirmPassword = driver.findElement(By.xpath("//input[@id='confpassword']"));
			WebElement registerClick = driver.findElement(By.xpath("//input[@id='submit']"));
			enterRegisteringUsername.sendKeys(username);
			enterRegisteringPassword.sendKeys(password);
			enterRegisteringConfirmPassword.sendKeys(password);
			registerClick.click();
			System.out.println("initialised");
		}
	}

	@After
	public void cleanUp() {
		WebElement navBarLogout = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
		navBarLogout.click();
		driver.manage().deleteAllCookies();
//		driver.close();
	}

	@Given("^I have accessed the website$")
	public void i_have_accessed_the_website() throws Throwable {
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^Registered and logged in$")
	public void registered_and_logged_in() throws Throwable {
		new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='logarea']")));
		WebElement navBarLogin = driver.findElement(By.xpath("//a[contains(text(),'Log in')]"));
		navBarLogin.click();
		assertEquals("Login", driver.getTitle());
		WebElement enterLoginUsername = driver.findElement(By.xpath("//input[@id='username']"));
		WebElement enterLoginPassword = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement loginClick = driver.findElement(By.xpath("//input[@id='submit']"));
		enterLoginUsername.sendKeys(username);
		enterLoginPassword.sendKeys(password);
		loginClick.click();
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());

	}

	@And("^I navigate to the update page for tracks$")
	public void i_navigate_to_the_update_page_for_tracks() throws Throwable {
		WebElement trackDropdown = driver.findElement(By.xpath("//body/div[1]/div[1]/div[4]/button[2]"));
		WebElement trackUpdate = driver.findElement(By.xpath("/html/body/div[1]/div/div[4]/div/a[2]"));
		trackDropdown.click();
		trackUpdate.click();
	}

	@Then("^I will select the fields to update a track$")
	public void i_will_select_the_fields_to_update_a_track() throws Throwable {
		WebElement updateTrackDropdown = driver.findElement(By.id("swordOfDamocles"));
		updateTrackDropdown.click();
		
		WebElement updateTrackSelector = driver.findElement(By.xpath("//*[@id=\"swordOfDamocles\"]/option[2]"));
		updateTrackSelector.click();
		
		WebElement updateButton = driver.findElement(By.xpath("/html/body/div/button"));
		updateButton.click();
		
		WebElement trackNameInput = driver.findElement(By.id("track-name"));
		trackNameInput.click();
		trackNameInput.clear();
		trackNameInput.sendKeys("let's dance");
		
		WebElement durationInput = driver.findElement(By.id("duration"));
		durationInput.click();
		durationInput.sendKeys("160");
		
		WebElement lyricsInput = driver.findElement(By.id("inp-lyr"));
		lyricsInput.click();
		lyricsInput.sendKeys("let's dance all day!");
		
		WebElement updateTrackButton = driver.findElement(By.id("update-button"));
		updateTrackButton.click();
		
		
		WebElement logoHome = driver.findElement(By.xpath("/html/body/nav/a/img"));
		logoHome.click();
	}

	@And("^I navigate to the update page for genres$")
	public void i_navigate_to_the_update_page_for_genres() throws Throwable {
		WebElement genreDropdown = driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/button[2]"));
		WebElement updateGenre = driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div/a[2]"));
		genreDropdown.click();
		updateGenre.click();
	}

	@Then("^I will select the fields to update a genre$")
	public void i_will_select_the_fields_to_update_a_genre() throws Throwable {
		WebElement updateGenreDropdown = driver.findElement(By.id("swordOfDamocles"));
		updateGenreDropdown.click();
		
		WebElement updateGenreSelector = driver.findElement(By.xpath("//*[@id=\"swordOfDamocles\"]/option[2]"));
		updateGenreSelector.click();
		
		WebElement updateButton = driver.findElement(By.xpath("/html/body/div/button"));
		updateButton.click();
		
		WebElement genreNameInput = driver.findElement(By.id("genre-name"));
		genreNameInput.click();
		genreNameInput.clear();
		genreNameInput.sendKeys("disco");
		
		WebElement lyricsInput = driver.findElement(By.id("description"));
		lyricsInput.click();
		lyricsInput.sendKeys("Disco all night long");
		
		WebElement updateGenreButton = driver.findElement(By.id("update-button"));
		updateGenreButton.click();
		
		
		WebElement logoHome = driver.findElement(By.xpath("/html/body/nav/a/img"));
		logoHome.click();

	}

	@And("^I navigate to the update page for artists$")
	public void i_navigate_to_the_update_page_for_artists() throws Throwable {
		WebElement artistDropdown = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/button[2]"));
		WebElement updateArtist = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/a[2]"));
		artistDropdown.click();
		updateArtist.click();

	}

	@Then("^I will select the fields to update a artist$")
	public void i_will_select_the_fields_to_update_a_artist() throws Throwable {
		WebElement updateArtistDropdown = driver.findElement(By.id("swordOfDamocles"));
		updateArtistDropdown.click();
		
		WebElement updateArtistSelector = driver.findElement(By.xpath("//*[@id=\"swordOfDamocles\"]/option[2]"));
		updateArtistSelector.click();
		
		WebElement updateButton = driver.findElement(By.xpath("/html/body/div/button"));
		updateButton.click();
		
		WebElement updatedArtistName = driver.findElement(By.xpath("//*[@id=\"track-name\"]"));
		updatedArtistName.click();
		updatedArtistName.clear();
		updatedArtistName.sendKeys("Disco Tech");
		
		WebElement updateArtistButton = driver.findElement(By.xpath("//*[@id=\"artistName\"]"));
		updateArtistButton.click();
		
		
		WebElement logoHome = driver.findElement(By.xpath("/html/body/nav/a/img"));
		logoHome.click();
		
		
	}

	@And("^I navigate to the update page for album$")
	public void i_navigate_to_the_update_page_for_album() throws Throwable {
		WebElement albumDropdown = driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/button[2]"));
		WebElement updateAlbum = driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div/a[2]"));
		albumDropdown.click();
		updateAlbum.click();

	}

	@Then("^I will select the fields to update a album$")
	public void i_will_select_the_fields_to_update_a_album() throws Throwable {
		WebElement updateAlbumDropdown = driver.findElement(By.id("swordOfDamocles"));
		updateAlbumDropdown.click();
		
		WebElement updateAlbumSelector = driver.findElement(By.xpath("//*[@id=\"swordOfDamocles\"]/option[2]"));
		updateAlbumSelector.click();
		
		WebElement updateButton = driver.findElement(By.xpath("/html/body/div/button"));
		updateButton.click();
		
		WebElement albumNameInput = driver.findElement(By.id("album-name"));
		albumNameInput.click();
		albumNameInput.clear();
		albumNameInput.sendKeys("The best tracks of 2000");
		
		WebElement artistSelector = driver.findElement(By.id("artistSelectorAlbums"));
		artistSelector.click();
		
		WebElement artistSelection = driver.findElement(By.xpath("//*[@id=\"artistSelectorAlbums\"]/option"));
		artistSelection.click();
		
		WebElement coverInput = driver.findElement(By.id("customAlbumCover"));
		coverInput.clear();
		coverInput.click();
		coverInput.sendKeys("Disco Cover");
		
		WebElement genreSelector = driver.findElement(By.id("genreSelectorAlbums"));
		genreSelector.click();

		WebElement genreSelection = driver.findElement(By.xpath("//*[@id=\"genreSelectorAlbums\"]/option[2]"));
		genreSelection.click();
		
		WebElement trackSelector = driver.findElement(By.id("tracksSelector"));
		trackSelector.click();
		
		WebElement addButton = driver.findElement(By.id("addTrackToAlbum"));
		addButton.click();

		WebElement updateAlbumButton = driver.findElement(By.id("updateAlbum"));
		updateAlbumButton.click();

		WebElement logoHome = driver.findElement(By.xpath("/html/body/nav/a/img"));
		logoHome.click();
		
	}

	@And("^I navigate to the update page for playlist$")
	public void i_navigate_to_the_update_page_for_playlist() throws Throwable {
		WebElement playlistDropdown = driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/button[2]"));
		WebElement updatePlaylist = driver.findElement(By.xpath("/html/body/div[1]/div/div[5]/div/a[2]"));
		playlistDropdown.click();
		updatePlaylist.click();
		
	}

	@Then("^I will select the fields to update a playlist$")
	public void i_will_select_the_fields_to_update_a_playlist() throws Throwable {
		WebElement updatePlaylistDropdown = driver.findElement(By.id("swordOfDamocles"));
		updatePlaylistDropdown.click();
		
		WebElement updatePlaylistSelector = driver.findElement(By.xpath("//*[@id=\"swordOfDamocles\"]/option[2]"));
		updatePlaylistSelector.click();

		WebElement updatePlaylistButton = driver.findElement(By.xpath("/html/body/div/button"));
		updatePlaylistButton.click();
		
		
		
		WebElement playlistNameInput = driver.findElement(By.id("playlist-name"));
		playlistNameInput.clear();
		playlistNameInput.click();
		playlistNameInput.sendKeys("Running playlist");
		
		WebElement descriptionInput = driver.findElement(By.id("description"));
		descriptionInput.clear();
		descriptionInput.click();
		descriptionInput.sendKeys("Running mood");
		
		WebElement artworkInput = driver.findElement(By.id("art-work"));
		artworkInput.clear();
		artworkInput.click();
		artworkInput.sendKeys("Run run run");
		
		WebElement updateButton = driver.findElement(By.id("update-button"));
		updateButton.click();

		WebElement logoHome = driver.findElement(By.xpath("/html/body/nav/a/img"));
		logoHome.click();
		
		
	}
}
