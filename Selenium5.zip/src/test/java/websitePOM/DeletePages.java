package websitePOM;

public class DeletePages {

}
