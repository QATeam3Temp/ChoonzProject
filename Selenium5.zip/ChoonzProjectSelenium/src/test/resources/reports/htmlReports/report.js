$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/cuke/PlaylistHomepageFunction.feature");
formatter.feature({
  "line": 1,
  "name": "Choonz website",
  "description": "",
  "id": "choonz-website",
  "keyword": "Feature"
});
formatter.before({
  "duration": 7087582200,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have logged in and accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "PlaylistHomepage.i_have_logged_in_and_accessed_the_website()"
});
formatter.result({
  "duration": 1225587100,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "",
  "description": "",
  "id": "choonz-website;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "I will create a playlist",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I will view the playlist on the homepage",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaylistHomepage.i_will_crreate_a_playlist()"
});
formatter.result({
  "duration": 535120800,
  "status": "passed"
});
formatter.match({
  "location": "PlaylistHomepage.i_will_view_the_playlist_on_the_homepage()"
});
formatter.result({
  "duration": 129781100,
  "status": "passed"
});
formatter.after({
  "duration": 52558000,
  "status": "passed"
});
});