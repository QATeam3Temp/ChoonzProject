package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzCreatePlaylist {
	
	public static final String URL = "http://localhost:8082/createplaylist.html";
	
	@FindBy(xpath = "//input[@id='playlist-name']")
	private WebElement playlistName;
	
	@FindBy(xpath = "//textarea[@id='description']")
	private WebElement description;
	
	@FindBy(xpath = "//textarea[@id='art-work']")
	private WebElement artwork;
	
	@FindBy(xpath = "//button[@id='create-button']")
	private WebElement create;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement home;
	
	public void createPlaylist() {
		playlistName.sendKeys("testplaylist");
		description.sendKeys("test");
		artwork.sendKeys("test");
		create.click();
	}
	
	public void home() {
		home.click();
	}
	
}
