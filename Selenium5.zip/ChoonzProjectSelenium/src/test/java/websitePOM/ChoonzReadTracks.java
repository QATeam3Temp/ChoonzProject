package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzReadTracks {
	
	public static final String URL = "http://localhost:8082/tracks";
	
	@FindBy(xpath = "//a[contains(text(),'testtrack')]")
	private WebElement selectTrack;
	
	public void readTracks() {
		selectTrack.click();
	}
	
}
