package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzTrackDetails {
	
	public static final String URL = "http://localhost:8082/track?id=1";
	
	@FindBy(xpath = "//a[contains(text(),'testartist')]")
	private WebElement artistDetails;
	
	@FindBy(xpath = "//a[contains(text(),'testalbum')]")
	private WebElement albumDetails;
	
	@FindBy(xpath = "//a[contains(text(),'testgenre')]")
	private WebElement genreDetails;
	
	@FindBy(xpath = "//a[contains(text(),'testplaylist')]")
	private WebElement playlistDetails;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement home;

	public void selectArtist() {
		artistDetails.click();
	}
	
	public void selectAlbum() {
		albumDetails.click();
	}
	
	public void selectGenre() {
		genreDetails.click();
	}
	
	public void selectPlaylist() {
		playlistDetails.click();
	}
	
	public void home() {
		home.click();
	}
	
}
