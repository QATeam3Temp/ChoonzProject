package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzAlbumDetails {
	
	public static final String URL = "http://localhost:8082/album?id=1";
	
	@FindBy(xpath = "//a[contains(text(),'testartist')]")
	private WebElement viewArtist;
	
	@FindBy(xpath = "//a[contains(text(),'testgenre')]")
	private WebElement viewGenre;
	
	@FindBy(xpath = "//a[contains(text(),'testtrack')]")
	private WebElement viewTrack;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement home;
	
	public void viewArtist() {
		viewArtist.click();
	}
	
	public void viewGenre() {
		viewGenre.click();
	}
	
	public void viewTrack() {
		viewTrack.click();
	}
	
	public void home() {
		home.click();
	}
	
}
