package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzReadPlaylist {
	
	public static final String URL = "http://localhost:8082/playlists";
	
	@FindBy(xpath = "//a[contains(text(),'testplaylist')]")
	private WebElement readPlaylist;
	
	public void readPlaylist() {
		readPlaylist.click();
	}
	
}
