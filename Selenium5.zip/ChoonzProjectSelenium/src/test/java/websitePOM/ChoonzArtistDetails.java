package websitePOM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChoonzArtistDetails {
	
	public static final String URL = "http://localhost:8082/artist?id=1";

	@FindBy(css = "div.container div.row:nth-child(2) div.col-lg-4.col-sm-6.mb-4 div.card.h-100 > a:nth-child(2)")
	private WebElement viewAlbum;
	
	@FindBy(xpath = "//body/nav[1]/a[1]/img[1]")
	private WebElement home;
	
	public void viewAlbum() {
		viewAlbum.click();
	}
	
	public void home() {
		home.click();
	}
	
}
