package playlistHomepageTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import websitePOM.ChoonzCreatePlaylist;
import websitePOM.ChoonzIndexPage;
import websitePOM.ChoonzLoginPage;
import websitePOM.ChoonzRegisterPage;

public class PlaylistHomepage {
	
	private static WebDriver driver;
	private static boolean ran = false;
	
	static String username = "test" + Math.random();
	static String password = "test" + Math.random();

	@Before
	public static void init() {
		if (ran) {

		} else {
			ran = true;
			System.setProperty("webdriver.chrome.driver",
					"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
			ChromeOptions cOptions = new ChromeOptions();
			cOptions.setHeadless(true);
			cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
			cOptions.setCapability("network.cookie.cookieBehavior", 2);
			cOptions.setCapability("profiles.block_third_party_cookies", true);
			driver = new ChromeDriver(cOptions);
			driver.manage().window().setSize(new Dimension(1366, 768));
			driver.get(ChoonzIndexPage.URL);
			
			username = "test" + Math.random();
			password = "test" + Math.random();

			ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
			ChoonzRegisterPage register = PageFactory.initElements(driver, ChoonzRegisterPage.class);
			new WebDriverWait(driver, 5)
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
			index.register();
			assertEquals("Sign Up", driver.getTitle());
			register.register(username, password, password);
		}
	}

	@After
	public void cleanUp() {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.logout();
		driver.manage().deleteAllCookies();
//		driver.close();
	}
	
	@Given("^I have logged in and accessed the website$")
	public void i_have_logged_in_and_accessed_the_website() throws InterruptedException {
		new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='logarea']")));
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		ChoonzLoginPage login = PageFactory.initElements(driver, ChoonzLoginPage.class);
		index.login();
		assertEquals("Login", driver.getTitle());
		login.register(username, password);
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^I will create a playlist$")
	public void i_will_crreate_a_playlist() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.createPlaylist();
		ChoonzCreatePlaylist create = PageFactory.initElements(driver, ChoonzCreatePlaylist.class);
		create.createPlaylist();
		create.home();
	}

	@Then("^I will view the playlist on the homepage$")
	public void i_will_view_the_playlist_on_the_homepage() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.playlistHome();
		assertEquals("testplaylist", driver.getTitle());
		driver.navigate().back();
		}

}
