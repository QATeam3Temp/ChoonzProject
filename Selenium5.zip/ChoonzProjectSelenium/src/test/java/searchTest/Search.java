package searchTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import websitePOM.ChoonzIndexPage;

public class Search {

	private static WebDriver driver;
	private static boolean ran = false;

	@Before
	public static void init() {
		if (ran) {

		} else {
			ran = true;
			System.setProperty("webdriver.chrome.driver",
					"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
			ChromeOptions cOptions = new ChromeOptions();
			cOptions.setHeadless(true);
			cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
			cOptions.setCapability("network.cookie.cookieBehavior", 2);
			cOptions.setCapability("profiles.block_third_party_cookies", true);
			driver = new ChromeDriver(cOptions);
			driver.manage().window().setSize(new Dimension(1366, 768));
			driver.get(ChoonzIndexPage.URL);
		}
	}

	@After
	public void cleanUp() {
//		driver.close();
	}

	@Given("^I have accessed the website$")
	public void i_have_accessed_the_website() throws InterruptedException {
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^I navigate search for tracks$")
	public void i_navigate_search_for_tracks() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.searchTrack();
	}

	@Then("^I will display the results for tracks$")
	public void i_will_display_the_results_for_tracks() throws InterruptedException {
		assertEquals("http://localhost:8082/search?x=testtrack", driver.getCurrentUrl());
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'Track: testtrack')]")));
		driver.navigate().back();
	}

	@When("^I navigate search for genres$")
	public void i_navigate_search_for_genres() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readGenres();
	}

	@Then("^I will display the results for genres$")
	public void i_will_display_the_results_for_genres() throws InterruptedException {
		driver.getCurrentUrl();
		assertEquals("http://localhost:8082/search?x=testgenre", driver.getCurrentUrl());
		new WebDriverWait(driver, 5)
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'Genre: testgenre')]")));
		driver.navigate().back();
	}

	@When("^I navigate search for artists$")
	public void i_navigate_search_for_artists() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.searchArtist();
	}

	@Then("^I will display the results for artists$")
	public void i_will_display_the_results_for_artists() throws InterruptedException {
		assertEquals("http://localhost:8082/search?x=testartist", driver.getCurrentUrl());
		new WebDriverWait(driver, 5).until(
				ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'Artist: testartist')]")));
		driver.navigate().back();
	}

	@When("^I navigate search for album$")
	public void i_navigate_search_for_album() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.readAlbums();
	}

	@Then("^I will display the results for albums$")
	public void i_will_display_the_results_for_albums() throws InterruptedException {
		assertEquals("http://localhost:8082/search?x=testalbum", driver.getCurrentUrl());
		new WebDriverWait(driver, 5).until(
				ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'Playlist: testalbum')]")));
		driver.navigate().back();
	}

	@When("^I navigate search for playlist$")
	public void i_navigate_search_for_playlist() throws InterruptedException {
		ChoonzIndexPage index = PageFactory.initElements(driver, ChoonzIndexPage.class);
		index.searchPlaylist();
		}

	@Then("^I will display the results for playlists$")
	public void i_will_display_the_results_for_playlists() throws InterruptedException {
		assertEquals("http://localhost:8082/search?x=testplaylist", driver.getCurrentUrl());
		new WebDriverWait(driver, 5).until(
				ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'Playlist: testplaylist')]")));
		driver.navigate().back();
		}

}
