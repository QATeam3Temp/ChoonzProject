$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/cuke/deleteFunction.feature");
formatter.feature({
  "line": 1,
  "name": "Choonz website",
  "description": "",
  "id": "choonz-website",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "",
  "description": "",
  "id": "choonz-website;",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for \u003centity\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a \u003centity2\u003e",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "choonz-website;;",
  "rows": [
    {
      "cells": [
        "entity",
        "entity2"
      ],
      "line": 12,
      "id": "choonz-website;;;1"
    },
    {
      "cells": [
        "tracks",
        "track"
      ],
      "line": 13,
      "id": "choonz-website;;;2"
    },
    {
      "cells": [
        "genres",
        "genre"
      ],
      "line": 14,
      "id": "choonz-website;;;3"
    },
    {
      "cells": [
        "artists",
        "artist"
      ],
      "line": 15,
      "id": "choonz-website;;;4"
    },
    {
      "cells": [
        "album",
        "album"
      ],
      "line": 16,
      "id": "choonz-website;;;5"
    },
    {
      "cells": [
        "playlist",
        "playlist"
      ],
      "line": 17,
      "id": "choonz-website;;;6"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 7362181700,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Delete.I_have_accessed_the_website()"
});
formatter.result({
  "duration": 302847700,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "",
  "description": "",
  "id": "choonz-website;;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for tracks",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a track",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Delete.registered_and_logged_in()"
});
formatter.result({
  "duration": 468985600,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_navigate_to_the_delete_page_for_tracks()"
});
formatter.result({
  "duration": 140892600,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_will_select_the_record_to_delete_a_track()"
});
formatter.result({
  "duration": 236084200,
  "status": "passed"
});
formatter.after({
  "duration": 54972800,
  "status": "passed"
});
formatter.before({
  "duration": 59200,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Delete.I_have_accessed_the_website()"
});
formatter.result({
  "duration": 5131200,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "",
  "description": "",
  "id": "choonz-website;;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for genres",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a genre",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Delete.registered_and_logged_in()"
});
formatter.result({
  "duration": 387298600,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_navigate_to_the_delete_page_for_genres()"
});
formatter.result({
  "duration": 32000,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_will_select_the_record_to_delete_a_genre()"
});
formatter.result({
  "duration": 40900,
  "status": "passed"
});
formatter.after({
  "duration": 50892800,
  "status": "passed"
});
formatter.before({
  "duration": 26800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Delete.I_have_accessed_the_website()"
});
formatter.result({
  "duration": 5282300,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "",
  "description": "",
  "id": "choonz-website;;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for artists",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a artist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Delete.registered_and_logged_in()"
});
formatter.result({
  "duration": 375694500,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_navigate_to_the_delete_page_for_artists()"
});
formatter.result({
  "duration": 37700,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_will_select_the_record_to_delete_a_artist()"
});
formatter.result({
  "duration": 54400,
  "status": "passed"
});
formatter.after({
  "duration": 48160200,
  "status": "passed"
});
formatter.before({
  "duration": 23300,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Delete.I_have_accessed_the_website()"
});
formatter.result({
  "duration": 4926100,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "",
  "description": "",
  "id": "choonz-website;;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for album",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a album",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Delete.registered_and_logged_in()"
});
formatter.result({
  "duration": 407764800,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_navigate_to_the_delete_page_for_album()"
});
formatter.result({
  "duration": 63400,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_will_select_the_record_to_delete_a_album()"
});
formatter.result({
  "duration": 29500,
  "status": "passed"
});
formatter.after({
  "duration": 52918200,
  "status": "passed"
});
formatter.before({
  "duration": 16400,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "I have accessed the website",
  "keyword": "Given "
});
formatter.match({
  "location": "Delete.I_have_accessed_the_website()"
});
formatter.result({
  "duration": 7821100,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "",
  "description": "",
  "id": "choonz-website;;;6",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 7,
  "name": "Registered and logged in",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I navigate to the delete page for playlist",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I will select the record to delete a playlist",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Delete.registered_and_logged_in()"
});
formatter.result({
  "duration": 368362400,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_navigate_to_the_delete_page_for_playlist()"
});
formatter.result({
  "duration": 30400,
  "status": "passed"
});
formatter.match({
  "location": "Delete.i_will_select_the_record_to_delete_a_playlist()"
});
formatter.result({
  "duration": 39700,
  "status": "passed"
});
formatter.after({
  "duration": 46475600,
  "status": "passed"
});
});