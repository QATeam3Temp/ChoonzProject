package createTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Create {

	private static WebDriver driver;
	private static String URL = "http://localhost:8082";
	private static boolean ran = false;
	
	static String username = "test"+Math.random();
	static String password = "test"+Math.random();

	@Before
	public static void init() {
		if(ran) {
			
		}else {ran = true;
		System.setProperty("webdriver.chrome.driver",
				"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
		ChromeOptions cOptions = new ChromeOptions();
		cOptions.setHeadless(true);
		cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
		cOptions.setCapability("network.cookie.cookieBehavior", 2);
		cOptions.setCapability("profiles.block_third_party_cookies", true);
		driver = new ChromeDriver(cOptions);
		driver.manage().window().setSize(new Dimension(1366, 768));
		username = "test"+Math.random();
		password = "test"+Math.random();
		driver.get(URL);
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
		WebElement navBarSignUp = driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]"));
		navBarSignUp.click();
		assertEquals("Sign Up", driver.getTitle());
		WebElement enterRegisteringUsername = driver.findElement(By.xpath("//input[@id='username']"));
		WebElement enterRegisteringPassword = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement enterRegisteringConfirmPassword = driver.findElement(By.xpath("//input[@id='confpassword']"));
		WebElement registerClick = driver.findElement(By.xpath("//input[@id='submit']"));
		enterRegisteringUsername.sendKeys(username);
		enterRegisteringPassword.sendKeys(password);
		enterRegisteringConfirmPassword.sendKeys(password);
		registerClick.click();
		System.out.println("initialised");
		}
	}

	@After
	public void cleanUp() {
		WebElement navBarLogout = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
		navBarLogout.click();
		driver.manage().deleteAllCookies();
//		driver.close();
	}

	@Given("^I have accessed the website$")
	public void i_have_accessed_the_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^Registered and logged in$")
	public void registered_and_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the create page for tracks$")
	public void i_navigate_to_the_create_page_for_tracks() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the fields to create a track$")
	public void i_will_select_the_fields_to_create_a_track() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the create page for genres$")
	public void i_navigate_to_the_create_page_for_genres() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the fields to create a genre$")
	public void i_will_select_the_fields_to_create_a_genre() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the create page for artists$")
	public void i_navigate_to_the_create_page_for_artists() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the fields to create a artist$")
	public void i_will_select_the_fields_to_create_a_artist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the create page for album$")
	public void i_navigate_to_the_create_page_for_album() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the fields to create a album$")
	public void i_will_select_the_fields_to_create_a_album() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the create page for playlist$")
	public void i_navigate_to_the_create_page_for_playlist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the fields to create a playlist$")
	public void i_will_select_the_fields_to_create_a_playlist() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}
	
}
