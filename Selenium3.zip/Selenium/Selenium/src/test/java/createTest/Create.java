package createTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Create {
	
	private static WebDriver driver;
	private static String URL = "http://localhost:8082";
	private static boolean ran = false;
	
	static String username = "test"+Math.random();
	static String password = "test"+Math.random();

	@Before
	public static void init() {
		if(ran) {
			
		}else {ran = true;
		System.setProperty("webdriver.chrome.driver",
				"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
		ChromeOptions cOptions = new ChromeOptions();
		cOptions.setHeadless(true);
		cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
		cOptions.setCapability("network.cookie.cookieBehavior", 2);
		cOptions.setCapability("profiles.block_third_party_cookies", true);
		driver = new ChromeDriver(cOptions);
		driver.manage().window().setSize(new Dimension(1366, 768));
		username = "test"+Math.random();
		password = "test"+Math.random();
		driver.get(URL);
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
		WebElement navBarSignUp = driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]"));
		navBarSignUp.click();
		assertEquals("Sign Up", driver.getTitle());
		WebElement enterRegisteringUsername = driver.findElement(By.xpath("//input[@id='username']"));
		WebElement enterRegisteringPassword = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement enterRegisteringConfirmPassword = driver.findElement(By.xpath("//input[@id='confpassword']"));
		WebElement registerClick = driver.findElement(By.xpath("//input[@id='submit']"));
		enterRegisteringUsername.sendKeys(username);
		enterRegisteringPassword.sendKeys(password);
		enterRegisteringConfirmPassword.sendKeys(password);
		registerClick.click();
		System.out.println("initialised");
		}
	}

	@After
	public void cleanUp() {
		WebElement navBarLogout = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
		navBarLogout.click();
		driver.manage().deleteAllCookies();
//		driver.close();
	}
	
	

}
