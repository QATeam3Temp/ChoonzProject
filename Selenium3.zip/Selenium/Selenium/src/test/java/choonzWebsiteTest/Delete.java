package choonzWebsiteTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Delete {

	private static WebDriver driver;
	private static String URL = "http://localhost:8082";
	private static boolean ran = false;
	
	static String username = "test"+Math.random();
	static String password = "test"+Math.random();

	@Before
	public static void init() {
		if(ran) {
			
		}else {ran = true;
		System.setProperty("webdriver.chrome.driver",
				"src/test/resources/drivers/chromedriver-89-4280/chromedriver.exe");
		ChromeOptions cOptions = new ChromeOptions();
		cOptions.setHeadless(true);
		cOptions.setCapability("profile.default_content_setting_values.cookes", 2);
		cOptions.setCapability("network.cookie.cookieBehavior", 2);
		cOptions.setCapability("profiles.block_third_party_cookies", true);
		driver = new ChromeDriver(cOptions);
		driver.manage().window().setSize(new Dimension(1366, 768));
		username = "test"+Math.random();
		password = "test"+Math.random();
		driver.get(URL);
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.xpath("//a[contains(text(),'Sign Up')]")));
		WebElement navBarSignUp = driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]"));
		navBarSignUp.click();
		assertEquals("Sign Up", driver.getTitle());
		WebElement enterRegisteringUsername = driver.findElement(By.xpath("//input[@id='username']"));
		WebElement enterRegisteringPassword = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement enterRegisteringConfirmPassword = driver.findElement(By.xpath("//input[@id='confpassword']"));
		WebElement registerClick = driver.findElement(By.xpath("//input[@id='submit']"));
		enterRegisteringUsername.sendKeys(username);
		enterRegisteringPassword.sendKeys(password);
		enterRegisteringConfirmPassword.sendKeys(password);
		registerClick.click();
		System.out.println("initialised");
		}
	}

	@After
	public void cleanUp() {
		WebElement navBarLogout = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
		navBarLogout.click();
		driver.manage().deleteAllCookies();
//		driver.close();
	}

	@Given("^I have accessed the website$")
	public void I_have_accessed_the_website() throws InterruptedException {
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());
	}

	@When("^Registered and logged in$")
	public void registered_and_logged_in() throws InterruptedException {
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .elementToBeClickable(By.xpath("//div[@id='logarea']")));
		WebElement navBarLogin = driver.findElement(By.xpath("//a[contains(text(),'Log in')]"));
		navBarLogin.click();
		assertEquals("Login", driver.getTitle());
		WebElement enterLoginUsername = driver.findElement(By.xpath("//input[@id='username']"));
		WebElement enterLoginPassword = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement loginClick = driver.findElement(By.xpath("//input[@id='submit']"));
		enterLoginUsername.sendKeys(username);
		enterLoginPassword.sendKeys(password);
		loginClick.click();
		new WebDriverWait(driver, 5).until(ExpectedConditions
                .presenceOfElementLocated(By.xpath("//div[@id='logarea']")));
		assertEquals("Choonz Music", driver.getTitle());
	}
	
	@And("^I navigate to the delete page for tracks$")
	public void i_navigate_to_the_delete_page_for_tracks() throws InterruptedException {
		WebElement trackDropdown = driver.findElement(By.xpath("//body/div[1]/div[1]/div[4]/button[2]"));
		WebElement trackDelete = driver.findElement(By.xpath("//body[1]/div[1]/div[1]/div[4]/div[1]/a[3]"));
		trackDropdown.click();
		trackDelete.click();		
	}

	@Then("^I will select the record to delete a track$")
	public void i_will_select_the_record_to_delete_a_track() throws InterruptedException {
		WebElement trackList = driver.findElement(By.id("swordOfDamocles"));
		WebElement track1 = driver.findElement(By.xpath("//option[contains(text(),'test')]"));
		WebElement deleteTrack = driver.findElement(By.xpath("//button[contains(text(),'delet this')]"));
		trackList.click();
		track1.click();
		deleteTrack.click();
		WebElement homepage = driver.findElement(By.xpath("//body/nav[1]/a[1]/img[1]"));
		homepage.click();
	}

	@And("^I navigate to the delete page for genres$")
	public void i_navigate_to_the_delete_page_for_genres() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the record to delete a genre$")
	public void i_will_select_the_record_to_delete_a_genre() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the delete page for artists$")
	public void i_navigate_to_the_delete_page_for_artists() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the record to delete a artist$")
	public void i_will_select_the_record_to_delete_a_artist() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the delete page for album$")
	public void i_navigate_to_the_delete_page_for_album() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the record to delete a album$")
	public void i_will_select_the_record_to_delete_a_album() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@And("^I navigate to the delete page for playlist$")
	public void i_navigate_to_the_delete_page_for_playlist() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will select the record to delete a playlist$")
	public void i_will_select_the_record_to_delete_a_playlist() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
	}

}
