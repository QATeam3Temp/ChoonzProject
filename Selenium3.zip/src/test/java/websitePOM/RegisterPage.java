package websitePOM;

import org.openqa.selenium.WebDriver;

public class RegisterPage {

	public final static String URL = "http://localhost:8082/signup.html";
	
	private WebDriver driver;
	
	
	
}
